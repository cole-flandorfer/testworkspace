package interfaceImplement;

public interface Incrementor {
	
	abstract void increment();
	
}
