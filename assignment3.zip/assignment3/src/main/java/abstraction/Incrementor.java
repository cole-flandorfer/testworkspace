package abstraction;

public class Incrementor extends Accumulator{
	public void operate() {
		acc++;
	}
}
