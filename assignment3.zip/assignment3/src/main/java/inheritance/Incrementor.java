package inheritance;

public class Incrementor {
	protected int total;
	
	public void increment() {
		total++;
	}
	
	public int getTotal() {
		return total;
	}
}
