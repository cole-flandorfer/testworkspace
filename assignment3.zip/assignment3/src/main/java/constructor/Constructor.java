package constructor;

public class Constructor {

	public static void main(String[] args) {
		MultiConstructor a = new MultiConstructor();
		MultiConstructor b = new MultiConstructor(7);

	}

}
