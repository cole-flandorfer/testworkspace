package constructor;

public class MultiConstructor {
	MultiConstructor(){
		System.out.println("Default constructor called");
	}
	
	MultiConstructor(int i){
		System.out.println("Overloaded constructor with int parameter called, passed: " + i);
	}
	
	
	
	
}
