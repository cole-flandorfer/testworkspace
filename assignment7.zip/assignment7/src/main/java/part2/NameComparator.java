package part2;

import java.util.Comparator;

public class NameComparator implements Comparator<Cmparator>{
	public int compare(Cmparator c1, Cmparator c2) {
		return c1.getName().compareTo(c2.getName());
	}
}
